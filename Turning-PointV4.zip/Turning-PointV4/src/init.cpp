#include "main.h"

void initialize()
{
  SetupMain();

  setTeamName("Fluxion");
  ReportStatus("Initialized\n");
}
