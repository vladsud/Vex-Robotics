//Created by Jason Zhang, Feburary 9, 2018
/** @file auto.c
 * @brief File for autonomous code
 *
 * This file should contain the user autonomous() function and any functions related to it.
 *
 * Any copyright is dedicated to the Public Domain.
 * http://creativecommons.org/publicdomain/zero/1.0/
 *
 * PROS contains FreeRTOS (http://www.freertos.org) whose source code may be
 * obtained from http://sourceforge.net/projects/freertos/files/ or on request.
 */

#include "main.h"
#include "cycle.h"
#include "actions.h"
#include "actionsMove.h"
#include "actionsTurn.h"


enum class AtonMode
{
	Regular,
	Skills,
	ManualSkills,
#ifndef OFFICIAL_RUN
	TestRun,
	ManualAuto,
#endif
};

AtonMode g_mode = AtonMode::Regular;
int g_midFlagHeight = 61;
int g_highFlagHeight = 65;

// Variables not to touch - control actual autonomous mode
bool g_autonomousSmartsOn = true;
bool g_manualSmarts = false;
bool g_alreadyRunAutonomous = false;


bool isAuto()
{
#ifndef OFFICIAL_RUN
    if (g_mode == AtonMode::ManualAuto || g_mode == AtonMode::Skills)
	    return true;
#endif // OFFICIAL_RUN
    return isAutonomous();
}

bool SmartsOn()
{
    // if we enable smarts in manual, then then have to be on in autonomous
    Assert(!g_manualSmarts || g_autonomousSmartsOn);
    if (g_manualSmarts)
        return true;
    return g_autonomousSmartsOn && isAuto();
}

void SetSkillSelection(bool skills)
{
    if (skills)
        g_mode = AtonMode::Skills;
    else
        g_mode = AtonMode::Regular;
}

#ifdef OFFICIAL_RUN
#  define Do(x) DoCore(x)
#else //OFFICIAL_RUN 
#  define Do(x)						\
    do {						\
	if (PrintDiagnostics(Diagnostics::Autonomous))	\
            puts("Next action started");		\
        DoCore(x);					\
    } while(false)
#endif //OFFICIAL_RUN 

void DoCore(Action&& action)
{

    while (!action.ShouldStop())
    {
        GetMain().Update();
    }
    action.Stop();
}

void autonomous()
{
#ifndef OFFICIAL_RUN
    // Safety net: run autonomous only once!
    // Siable second run, in case manual auto was still in place when running on competition.
    if (g_alreadyRunAutonomous && !isAutonomous())
    {
	g_mode = AtonMode::Regular;
        return;
    }
    g_alreadyRunAutonomous = true;
    if (!isAutonomous() && g_mode != AtonMode::ManualSkills)
        delay(2000);
#endif

    ReportStatus("\n*** Autonomous: Start ***\n\n");
    ReportStatus ("Time: %d\n", GetMain().GetTime());

    Main& main = SetupMain();

    // all system update their counters, like distance counter.
    main.UpdateAllSystems();

#ifndef OFFICIAL_RUN
    // Debugging code - should not run in real autonomous
    if (g_mode == AtonMode::TestRun && !isAutonomous())
    {
        // Do(TurnToPoint(-20000, -10000));
        // Do(Wait(2000));
        // Do(TurnToPoint(0, -10000));
        // Do(Wait(2000));
        // Do(TurnToPoint(10000, 10000));
        // Do(Wait(2000));
        Do(Turn(90));
	// Do(ShooterAngle(true, 24, false /*checkPresenceOfBall*/));
        // Do(Wait(200));
        // Do(ShooterAngle(false, 48, false /*checkPresenceOfBall*/));
        // Do(Wait(200));
        // Do(ShooterAngle(true, 24, false /*checkPresenceOfBall*/));
        // Do(Wait(200));
        // GetMain().shooter.SetFlag(Flag::Loading);
        // Do(Wait(1000));
        //Do(ShooterAngle(true, TestDistance, false /*checkPresenceOfBall*/));
        //Do(Wait(500));
        //Do(ShooterAngle(false, TestDistance, false /*checkPresenceOfBall*/));
        //Do(Wait(500));
        Do(EndOfAction());
        return;
    }
#endif // !OFFICIAL_RUN

    if (g_mode == AtonMode::Skills)
    {
        auto& lcd = GetMain().lcd;
	lcd.AtonBlueRight = false;
	lcd.AtonFirstPos = true;
	lcd.AtonClimbPlatform = true;
    }

    if (GetMain().lcd.AtonBlueRight)
    {
        GetMain().tracker.FlipX();
        GetMain().drive.FlipX();
    }

    // WARNING:
    // All coordinates and gyro-based turns are from the POV of RED (Left) position
    // For Blue (right) automatic transformation happens
    PositionInfo info;
    if (GetMain().lcd.AtonFirstPos)
    {
        GetMain().tracker.SetCoordinates({16, 60, -90});

        // async
	ShooterSetAngle(true /*high*/, g_midFlagHeight, false /*checkPresenceOfBall*/);

        // knock the cone
        Do(Move(50, 40));
        Do(Move(1200, 85));
        Do(IntakeUp());
        Do(Move(200, 20));
        Do(Wait(300));
        Do(MoveTimeBased(-18, 100)); // attempt to fully stop, for more accurate back movement
        Do(MoveExact(-1950));
        Do(IntakeStop());

	if (GetMain().lcd.AtonBlueRight)
	   Do(TurnToPoint(20, 0));
	else
	   Do(TurnToPoint(19, 0));

        info = GetTracker().LatestPosition(false /*clicks*/);
	printf("Shooting: X,Y,A inches: (%f, %f), A = %d\n", info.X, info.Y, info.gyro);

       // Shoot the ball
        Do(ShooterAngle(true /*high*/, g_midFlagHeight, false /*checkPresenceOfBall*/));
        Do(ShootBall());
        Do(IntakeUp());
	// wait for it to go down & start moving up
	GetMain().shooter.SetDistance(g_highFlagHeight);
	if (g_mode == AtonMode::Skills)
            Do(WaitShooterAngleToGoUp(5000)); 
	else
            Do(WaitShooterAngleToGoUp(1500)); 
        Do(ShooterAngle(false /*high*/, g_highFlagHeight, false /*checkPresenceOfBall*/));
        Do(ShootBall());

	if (GetMain().lcd.AtonBlueRight)
	    Do(TurnToAngle(2));
	else
	    Do(TurnToAngle(8));
        Do(IntakeUp());

	if (g_mode == AtonMode::ManualSkills)
	    return;

	// Do(TurnToPoint(8, 0));

        // Do(Move(200, 45, 0));
        // Do(Move(550, 50, -3.5)); // turn left for red
        Do(Move(100, 35, 0, false /*StopOnColision */));
        Do(Move(2400, 85, 0, true /*StopOnColision */));
        Do(Wait(300));

        info = GetTracker().LatestPosition(true /*clicks*/);
	printf("Hit wall: X,Y,A clicks: (%f, %f), A = %d\n", info.X, info.Y, info.gyro);

	int distance = -4030;
	if (abs(info.gyro) > 15 * GyroWrapper::Multiplier || info.Y > 12.0 / PositionTracker::inchesPerClick)	
	{
		puts("Recovery!!!");
                Do(Wait(300));
	        Do(Move(100, -35, 0, false /*StopOnColision */));
	        Do(Wait(300));
		puts("   Turning");
		Do(TurnToAngle(CalcAngleToPoint(18, 84) + 180));
		puts("   End of recovery");

	        info = GetTracker().LatestPosition(true /*clicks*/);
		printf("After recovery: X,Y,A clicks: (%f %f), A = %d\n", info.X, info.Y, info.gyro);
		distance = int(info.Y - 78.0 / PositionTracker::inchesPerClick) * 2;
	}
        else
	{
		int distanceAlt = int(info.Y - 80.0 / PositionTracker::inchesPerClick) * 2;
		printf("Alternate calculation: %d (should be %d)\n", distanceAlt, distance);
	}


        if (GetMain().lcd.AtonClimbPlatform)
        {
	    printf("Moving: %d\n", distance);
	    Do(MoveExact(distance));
	
            Do(IntakeStop()); // sometimes it turns off due to ball shaking - very annoying
	    Do(Turn(-90));

	    ReportStatus("First platform\n");
            Do(MoveToPlatform(3650, 85));

	    if (g_mode != AtonMode::Skills)
	    {
                Do(MoveTimeBased(30, 100));
                // Do(MoveTimeBased(18, 100));
                // Do(MoveTimeBased(-30, 100));
	    }
	    else
	    {
                // SECOND PLATFORM
	        ReportStatus("Second platform\n");
                Do(MoveToPlatform(3350, 85));
                Do(MoveTimeBased(-30, 100));
            }
        }
	else
	{
	    ReportStatus("Not climbing platform\n");
	    distance = distance / 2;
	    printf("Moving: %d\n", distance);
	    Do(MoveExact(distance));
	}
        Do(IntakeStop());
    }
    else
    {
        GetMain().tracker.SetCoordinates({16.5 - 1, 33 + 48 - 1, -30});

        Do(Wait(7000));
        // Shoot the ball
        Do(ShooterAngle(false, 108, false /*checkPresenceOfBall*/));
        Do(ShootBall());

        if (GetMain().lcd.AtonClimbPlatform)
        {
            //Do(ShooterAngle(false, 108, false /*checkPresenceOfBall*/),
            // give some time for other robot to get out of the way
            // FYI: It takes about 7 seconds to park
            //Do(Wait(400),
            //Do(ShootBall,
            Do(Move(700, 50));
            Do(Wait(1000));
            // should be same: Do(TurnToAngle(-90));
            Do(Turn(-60));
            Do(Wait(200));
            Do(Move(400, 85));
            Do(MoveToPlatform(3250, 85));
        }
    }

    Do(EndOfAction());

    if (PrintDiagnostics(Diagnostics::Autonomous))
        printf("\n *** Auto: Exit ***\n\n");
}
